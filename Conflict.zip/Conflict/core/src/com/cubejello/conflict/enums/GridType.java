package com.cubejello.conflict.enums;

/**
 * Created by Jake on 8/12/2017.
 */

public enum GridType {
    WATER,
    GRASS,
    SAND
}
