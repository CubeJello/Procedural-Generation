package com.cubejello.conflict.enums;

/**
 * Created by Jake on 8/13/2017.
 */

public enum OccupantType {
    TREE
}
