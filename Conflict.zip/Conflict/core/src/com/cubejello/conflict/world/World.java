package com.cubejello.conflict.world;

import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.utils.Array;
import com.cubejello.conflict.grid.Grid;
import com.cubejello.conflict.utils.Constants;

/**
 * Created by Jake on 8/11/2017.
 */

public class World {
    private Grid grid;

    public World() {
        grid = new Grid();
        grid.initialize(Constants.GRID_WIDTH, Constants.GRID_HEIGHT, Constants.SPACE_SIZE);
    }

    public Array<Sprite> getSprites() {
        return grid.getSprites();
    }
}
