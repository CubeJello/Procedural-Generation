package com.cubejello.conflict.grid;

import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.Array;
import com.cubejello.conflict.enums.GridType;
import com.cubejello.conflict.occupants.Occupant;
import com.cubejello.conflict.occupants.Tree;
import com.cubejello.conflict.utils.Constants;
import com.cubejello.conflict.utils.RandomUtils;

/**
 * Created by Jake on 8/11/2017.
 */

public class Grid {
    private Array<GridSpace> gridSpaces;
    private Array<Occupant> occupants;

    public void initialize(float width, float height, float spaceSize) {
        gridSpaces = new Array<GridSpace>();
        occupants = new Array<Occupant>();

        for(float y = 0; y < height; y += spaceSize) {
            for (float x = 0; x < width; x += spaceSize) {
                GridSpace gridSpace = new GridSpace(GridType.GRASS, x, y);
                if(RandomUtils.pseudoRandom(0, 1) < 0.01)
                    gridSpace.setType(GridType.WATER);

                for(GridSpace adjGridSpace : getAdjacentGridSpaces(gridSpace)) {
                    if(adjGridSpace.getType() == GridType.WATER && RandomUtils.pseudoRandom(0, 1) < 0.5)
                        gridSpace.setType(GridType.WATER);
                }
                gridSpaces.add(gridSpace);
            }
        }
        fixGridSpaces();
    }

    private void fixGridSpaces() {
        for(int i = 0; i < gridSpaces.size; i++) {
            if(gridSpaces.get(i).getType().equals(GridType.WATER)) {
                int i2 = 0;
                for (GridSpace adjGridSpace : getAdjacentGridSpaces(gridSpaces.get(i))) {
                    if (adjGridSpace.getType() != GridType.WATER)
                        i2++;
                }
                if(i2 >= 4) {
                    gridSpaces.get(i).setType(GridType.GRASS);
                }
            } else if(!gridSpaces.get(i).getType().equals(GridType.WATER)) {
                for(GridSpace gridSpace : getAdjacentGridSpaces(gridSpaces.get(i))) {
                    if(gridSpace.getType().equals(GridType.WATER)) {
                        gridSpaces.get(i).setType(GridType.SAND);
                    }

                }
                if(gridSpaces.get(i).getType().equals(GridType.GRASS) && RandomUtils.pseudoRandom(0, 1) < 0.1) {
                    Tree tree = new Tree(gridSpaces.get(i).getPosition());
                    occupants.add(tree);
                }
            }
        }
    }

    public Array<Vector2> getGridPos() {
        Array<Vector2> gridPositions = new Array<Vector2>();
        for(GridSpace gridSpace : gridSpaces)
            gridPositions.add(gridSpace.getPosition());
        return gridPositions;
    }

    public Array<Sprite> getSprites() {
        Array<Sprite> spritesToReturn = new Array<Sprite>();

        for(GridSpace gridSpace : gridSpaces) {
            spritesToReturn.add(gridSpace.getSprite());
        }
        for(Occupant occupant : occupants) {
            spritesToReturn.add(occupant.getSprite());
        }
        return spritesToReturn;
    }

    private Array<GridSpace> getAdjacentGridSpaces(GridSpace targetSpace) {
        Array<GridSpace> gridSpacesToReturn = new Array<GridSpace>();

        for(GridSpace gridSpace : gridSpaces) {
            if(gridSpace.getPosition().y == targetSpace.getPosition().y) {
                if (gridSpace.getPosition().x - Constants.SPACE_SIZE == targetSpace.getPosition().x || gridSpace.getPosition().x + Constants.SPACE_SIZE == targetSpace.getPosition().x)
                    gridSpacesToReturn.add(gridSpace);
            } else if(gridSpace.getPosition().x == targetSpace.getPosition().x) {
                if(gridSpace.getPosition().y - Constants.SPACE_SIZE == targetSpace.getPosition().y || gridSpace.getPosition().y + Constants.SPACE_SIZE == targetSpace.getPosition().y)
                    gridSpacesToReturn.add(gridSpace);
            }
        }

        return gridSpacesToReturn;
    }
}
