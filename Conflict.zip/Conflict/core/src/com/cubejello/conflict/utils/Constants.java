package com.cubejello.conflict.utils;

/**
 * Created by Jake on 8/11/2017.
 */

public class Constants {
    public static final int APP_WIDTH = 600;
    public static final int APP_HEIGHT = 600;

    public static final float GRID_WIDTH = 600;
    public static final float GRID_HEIGHT = 600;
    public static final float SPACE_SIZE = GRID_WIDTH / 30;
}
